Warrior:
	W
                                +   F替身         G攻击
         A     S     D   
Archer:
	↑
                                +   K替身         L攻击
        ←     ↓     →  	